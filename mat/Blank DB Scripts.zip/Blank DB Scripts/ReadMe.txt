Follow the sql Sequence:
1)MAT_APP_FAKE.sql
2)measurepackage.sql
3)inserts.sql
4)firstInit.sql
5)SecondInit.sql
6)ThirdInit.sql
7)FourthInit.sql 